
import Control.Controller;

public class Main {
    public static void main(String[] args) {
        Controller manager = new Controller();
        manager.runner();
    }
}
